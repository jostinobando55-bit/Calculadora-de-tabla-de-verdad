# Generador de tablas de verdad

## Ejecutar localmente
1. Instala Python 3.10 o superior.
2. En una terminal dentro de esta carpeta ejecuta: `pip install -r requirements.txt`
3. Ejecuta: `streamlit run app.py`

## Publicar con GitHub y Streamlit Community Cloud
1. Crea un repositorio nuevo en GitHub.
2. Sube `app.py` y `requirements.txt`.
3. Entra a Streamlit Community Cloud e inicia sesión con GitHub.
4. Selecciona **Create app**, el repositorio y `app.py`.
5. Pulsa **Deploy**. Al terminar tendrás una URL pública para compartir.

## Operadores
`¬p` / `~p` negación; `p ∧ q` / `p & q` conjunción; `p ∨ q` / `p | q` disyunción; `p ⊕ q` / `p ^ q` XOR; `p → q` / `p -> q` implicación; `p ↔ q` / `p <-> q` bicondicional. Se admiten paréntesis y hasta 8 variables.
